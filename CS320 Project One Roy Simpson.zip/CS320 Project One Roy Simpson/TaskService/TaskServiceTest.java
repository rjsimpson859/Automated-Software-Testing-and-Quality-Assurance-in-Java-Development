
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("Task ID", "Name", "Required Description #1");
        taskService.addTask(task);        
    }

    @Test
    public void testAddTaskDuplicateId() {
        Task Name = new Task("Task ID", "Name", "Required Description #1");
        Task Name2 = new Task("Task ID", "Name2", "Required Description #2");
        taskService.addTask(Name);
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(Name2);
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("Task ID", "Name", "Required Description #1");
        taskService.addTask(task);
        taskService.deleteTask("Task ID");       
    }

    @Test
    public void testDeleteTaskNonexistentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("Task ID");
        });
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("Task ID", "Name", "Required Description #1");
        taskService.addTask(task);
        taskService.updateTask("Task ID", "NewName", null);
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("Task ID", "Name", "Required Description #1");
        taskService.addTask(task);
        taskService.updateTask("Task ID", null, "NewRequired Description #1");
    }

    @Test
    public void testUpdateTaskNonexistentId() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("Task ID", "NewName", "NewRequired Description #1");
        });
    }

    @Test
    public void testUpdateTaskNameTooLong() {
        Task task = new Task("Task ID", "Name", "Required Description #1");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("Task ID", "TaskNameTooLong12345678901", null);
        });
    }

    @Test
    public void testUpdateTaskDescriptionTooLong() {
        Task task = new Task("Task ID", "Name", "Required Description #1");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask("Task ID", null, "Required Description Too Long! Required Description Too Long! Required Description Too Long!");
        });
    }
}
