import java.util.*;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("This task ID already exists, please try a different one.");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("This task ID does not exist, please try a vaild task ID.");
        }
        tasks.remove(taskId);
    }

    public void updateTask(String taskId, String name, String description) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("This task ID does not exist, please try a vaild task ID.");
        }
        Task task = tasks.get(taskId);
        if (name != null) {
            if (name.length() > 20) {
                throw new IllegalArgumentException("Name cannont be longer than 20 charters. ");
            }
            task = new Task(taskId, name, task.getDescription());
        }
        if (description != null) {
            if (description.length() > 50) {
                throw new IllegalArgumentException("Description cannot be longer thant 50 charters.");
            }
            task = new Task(taskId, task.getName(), description);
        }
        tasks.put(taskId, task);
    }
}
