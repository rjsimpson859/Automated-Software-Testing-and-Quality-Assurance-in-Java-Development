import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {
    @Test
    void testConstructorWithValidArguments() {
        Task task = new Task("1234567890", "Name", "Required Description");
        Assertions.assertEquals("1234567890", task.getTaskId());
        Assertions.assertEquals("Name", task.getName());
        Assertions.assertEquals("Required Description", task.getDescription());
    }

    @Test
    void testConstructorWithNullTaskId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Required Description");
        });
    }

    @Test
    void testConstructorWithInvalidTaskIdLength() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Required Description");
        });
    }

    @Test
    void testConstructorWithNullName() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", null, "Required Description");
        });
    }

    @Test
    void testConstructorWithInvalidNameLength() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "This name is too long.", "Required Description");
        });
    }

    @Test
    void testConstructorWithNullDescription() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Name", null);
        });
    }

    @Test
    void testConstructorWithInvalidDescriptionLength() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890", "Name", "Required Description is too long and will not be allowed. Required Description is too long and will not be allowed.");
        });
    }
}
