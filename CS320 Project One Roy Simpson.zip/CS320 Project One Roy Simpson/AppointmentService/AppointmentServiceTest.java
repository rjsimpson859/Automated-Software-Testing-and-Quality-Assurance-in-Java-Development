import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentServiceTest {
    @Test
    public void testAddAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        String id = "1234567890";
        Date appointmentDate = new Date(System.currentTimeMillis() + 1000*60*60*24); // tomorrow
        String description = "Valid appointment";
        Appointment appointment = new Appointment(id, appointmentDate, description);
        appointmentService.addAppointment(appointment);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddDuplicateAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        String id = "1234567890";
        Date appointmentDate = new Date(System.currentTimeMillis() + 1000*60*60*24);
        String description = "Valid appointment";
        Appointment appointment1 = new Appointment(id, appointmentDate, description);
        Appointment appointment2 = new Appointment(id, appointmentDate, description);
        appointmentService.addAppointment(appointment1);
        appointmentService.addAppointment(appointment2);
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        String id = "1234567890";
        Date appointmentDate = new Date(System.currentTimeMillis() + 1000*60*60*24); 
        String description = "Valid appointment";
        Appointment appointment = new Appointment(id, appointmentDate, description);
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment(id);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonExistingAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        String id = "1234567890";
        appointmentService.deleteAppointment(id);
    }
}
