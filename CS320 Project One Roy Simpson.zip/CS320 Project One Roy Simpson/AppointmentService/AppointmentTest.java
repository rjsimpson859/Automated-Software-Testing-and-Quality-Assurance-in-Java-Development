import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentTest {
    @Test
    public void testValidAppointment() {
        String id = "1234567890";
        Date appointmentDate = new Date(System.currentTimeMillis() + 1000*60*60*24); // tomorrow
        String description = "Valid appointment";
        Appointment appointment = new Appointment(id, appointmentDate, description);
        assertEquals(id, appointment.getId());
        assertEquals(appointmentDate, appointment.getAppointmentDate());
        assertEquals(description, appointment.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTooLongId() {
        String id = "1234567890123"; // too long for the ID
        Date appointmentDate = new Date(System.currentTimeMillis() + 1000*60*60*24); // tomorrow
        String description = "Appointment ID is too long, must be less than 10 charters";
        new Appointment(id, appointmentDate, description);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPastDate() {
        String id = "1234567890";
        Date appointmentDate = new Date(System.currentTimeMillis() - 1000*60*60*24); // yesterday, date in the past -> not valid
        String description = "Appointment date cannot be in the past";
        new Appointment(id, appointmentDate, description);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTooLongDescription() {
        String id = "1234567890";
        Date appointmentDate = new Date(System.currentTimeMillis() + 1000*60*60*24); // tomorrow
        String description = "The description cannot be greater than 50 charters. The description cannot be greater than 50 charters.";
        new Appointment(id, appointmentDate, description);
    }
}
