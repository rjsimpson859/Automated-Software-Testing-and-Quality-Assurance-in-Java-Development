import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments;

    public AppointmentService() {
        appointments = new HashMap<>();
    }

    public void addAppointment(Appointment appointment) {
        String appointmentId = appointment.getId();
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment already exists");
        }
        appointments.put(appointmentId, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment does not exist");
        }
        appointments.remove(appointmentId);
    }
}